import React from 'react';

const Users = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Manage Users</h1>
    </div>
  );
};

export default Users;
