import React from 'react';

const AdminProducts = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Manage Products</h1>
    </div>
  );
};

export default AdminProducts;
