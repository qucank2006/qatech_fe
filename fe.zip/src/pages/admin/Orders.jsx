import React from 'react';

const Orders = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Manage Orders</h1>
    </div>
  );
};

export default Orders;
