//                       _oo0oo_
//                      o8888888o
//                      88" . "88
//                      (| -_- |)
//                      0\  =  /0
//                    ___/`---'\___
//                  .' \\|     |// '.
//                 / \\|||  :  |||// \
//                / _||||| -:- |||||- \
//               |   | \\\  -  /// |   |
//               | \_|  ''\---/''  |_/ |
//               \  .-\__  '-'  ___/-. /
//             ___'. .'  /--.--\  `. .'___
//          ."" '<  `.___\_<|>_/___.' >' "".
//         | | :  `- \`.;`\ _ /`;.`/ - ` : | |
//         \  \ `_.   \_ __\ /__ _/   .-` /  /
//     =====`-.____`.___ \_____/___.-`___.-'=====
//                       `=---='
//
//     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//            Phật phù hộ, không bao giờ BUG
//     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import LogoLoop from "../components/LogoLoop";
import { techLogos } from "../data/logos";
import StoreCarousel from "../components/StoreCarousel";
import { storeImages } from "../data/storeImg";
import { LuTruck, LuShieldCheck, LuHeadphones } from "react-icons/lu";

export default function Home() {
  // Animation Variants
  const fadeInUp = {
    hidden: { opacity: 0, y: 40 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
  };

  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <div className="w-full flex flex-col items-center text-center overflow-hidden">
      
      {/* HERO SECTION */}
      <motion.section 
        className="min-h-[85vh] flex flex-col justify-center items-center px-4"
        initial="hidden"
        animate="visible"
        variants={fadeInUp}
      >
        <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-indigo-500 to-cyan-400 bg-clip-text text-transparent">
          Chào mừng đến với QATech
        </h1>

        <p className="text-xl text-neutral-400 mb-8 max-w-2xl mx-auto">
          Nền tảng mua sắm công nghệ hiện đại, tối ưu trải nghiệm và mang đến
          những sản phẩm chất lượng từ các thương hiệu hàng đầu thế giới.
        </p>

        <div className="flex gap-4 justify-center">
          <Link to="/products">
            <motion.button 
              whileHover={{ scale: 1.05, boxShadow: "0px 0px 15px rgba(79, 70, 229, 0.5)" }}
              whileTap={{ scale: 0.95 }}
              className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-semibold transition border border-transparent"
            >
              Mua ngay
            </motion.button>
          </Link>

          <Link to="/register">
            <motion.button 
              whileHover={{ scale: 1.05, boxShadow: "0px 0px 15px rgba(255, 255, 255, 0.1)", borderColor: "#fff" }}
              whileTap={{ scale: 0.95 }}
              className="bg-neutral-800 text-white px-8 py-3 rounded-xl font-semibold transition border border-neutral-700"
            >
              Đăng ký
            </motion.button>
          </Link>
        </div>
      </motion.section>

      {/* ABOUT SECTION */}
      <motion.section 
        className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 px-6 py-20 text-left"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
        variants={fadeInUp}
      >
        <div>
          <h2 className="text-3xl font-bold mb-4">QATech là gì?</h2>
          <p className="text-neutral-400 leading-relaxed mb-4">
            QATech là cửa hàng chuyên cung cấp thiết bị công nghệ như laptop, PC, màn hình 
            và phụ kiện chính hãng. Chúng tôi mang đến trải nghiệm mua sắm nhanh chóng, tiện lợi 
            cùng dịch vụ hỗ trợ tận tâm.
          </p>

          <p className="text-neutral-400 leading-relaxed mb-4">
            Tại QATech, mọi sản phẩm đều được kiểm duyệt kỹ lưỡng, đi kèm chế độ bảo
            hành rõ ràng cùng dịch vụ hỗ trợ tận tâm. Đội ngũ tư vấn luôn sẵn sàng đồng
            hành để bạn không phải lăn tăn về chất lượng hay giá cả.
          </p>

          <p className="text-neutral-400 leading-relaxed">
            QATech mang đến cảm giác mua sắm “đi trước thời đại” — nơi bạn có thể khám phá công nghệ
            mới nhất trong không gian trực quan, mượt mà và đầy cảm hứng.
          </p>
        </div>

        <div className="rounded-2xl bg-[#111] border border-neutral-800 p-2">
          <StoreCarousel images={storeImages.map(i => i.src)} />
        </div>

      </motion.section>

      {/* WHY CHOOSE US */}
      <section className="max-w-6xl mx-auto py-20 px-6">
        <motion.h2 
          className="text-3xl font-bold mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          Tại sao chọn QATech?
        </motion.h2>

        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-10"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
          variants={staggerContainer}
        >
          {[
            { icon: LuTruck, title: "Giao hàng nhanh", desc: "Nhanh chóng, đúng hẹn, hỗ trợ mọi nơi." },
            { icon: LuShieldCheck, title: "Sản phẩm chính hãng", desc: "Cam kết 100% chất lượng từ thương hiệu lớn." },
            { icon: LuHeadphones, title: "Hỗ trợ tận tâm", desc: "Có mặt 24/7 khi bạn cần." }
          ].map((item, index) => (
            <motion.div 
              key={index}
              variants={fadeInUp}
              whileHover={{ y: -10, borderColor: "#4f46e5", boxShadow: "0px 10px 30px -10px rgba(79, 70, 229, 0.3)" }}
              className="p-6 bg-[#111] rounded-2xl border border-neutral-800 shadow-md transition-all duration-300"
            >
              <item.icon className="text-indigo-400 w-10 h-10 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
              <p className="text-neutral-400">{item.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* FEATURED PRODUCTS */}
      <section className="max-w-6xl mx-auto py-20 px-6">
        <motion.h2 
          className="text-3xl font-bold mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          Sản phẩm nổi bật (sau code BE gọi API)
        </motion.h2>

        <motion.div 
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
          variants={staggerContainer}
        >
          {[1, 2, 3, 4].map((_, i) => (
            <motion.div 
              key={i}
              variants={fadeInUp}
              whileHover={{ y: -8, borderColor: "#4f46e5", boxShadow: "0px 10px 25px -5px rgba(79, 70, 229, 0.25)" }}
              className="bg-[#111] border border-neutral-800 rounded-2xl p-4 transition-all duration-300 cursor-pointer group"
            >
              <div className="w-full h-40 bg-neutral-900 rounded-xl mb-4 flex items-center justify-center overflow-hidden">
                <p className="text-neutral-600 text-sm group-hover:scale-110 transition-transform duration-500">Ảnh sản phẩm</p>
              </div>

              <h3 className="text-lg font-semibold mb-2">Sản phẩm {i + 1}</h3>
              <p className="text-neutral-400 text-sm mb-3">
                Mô tả ngắn gọn về sản phẩm. Tương thích mọi nhu cầu của bạn.
              </p>

              <div className="flex justify-between items-center">
                <span className="text-indigo-400 font-semibold">25.000.000₫</span>
                <motion.button 
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="px-3 py-1 rounded-lg bg-indigo-600 text-white text-sm"
                >
                  Xem ngay
                </motion.button>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* CUSTOMER REVIEWS */}
      <section className="max-w-6xl mx-auto py-20 px-6">
        <motion.h2 
          className="text-3xl font-bold mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          Khách hàng nói gì về QATech?
        </motion.h2>

        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-10"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
          variants={staggerContainer}
        >
          {[
            {
              name: "Trần Lê Quốc Anh",
              review: "Dịch vụ quá tuyệt! Laptop nhận nhanh, đóng gói kỹ và đúng như mô tả.",
            },
            {
              name: "Đỗ Lam",
              review: "Nhân viên tư vấn rất nhiệt tình, giúp mình chọn đúng chiếc PC phù hợp.",
            },
            {
              name: "Nguyễn Thị Ánh Tuyết",
              review: "Giá tốt, sản phẩm chính hãng. Sẽ ủng hộ thêm!",
            },
          ].map((item, i) => (
            <motion.div 
              key={i}
              variants={fadeInUp}
              whileHover={{ scale: 1.02, borderColor: "#4f46e5" }}
              className="bg-[#111] border border-neutral-800 rounded-2xl p-6 shadow-md transition-all duration-300"
            >
              <p className="text-neutral-300 italic mb-4">“{item.review}”</p>
              <p className="text-neutral-500 text-sm">— {item.name}</p>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* LOGO LOOP */}
      <motion.section 
        className="w-full max-w-6xl min-h-[120px] relative overflow-hidden py-10 mb-10"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
      >
        <h2 className="text-3xl font-bold mb-12">Các thương hiệu hàng đầu</h2>

        <LogoLoop
          logos={techLogos}
          speed={120}
          direction="left"
          logoHeight={48}
          gap={40}
          fadeOut
          scaleOnHover
          ariaLabel="Tech Logos"
        />
      </motion.section>

      <motion.section 
        className="py-20 w-full text-center"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={fadeInUp}
      >
        <h2 className="text-3xl font-bold mb-4">Sẵn sàng khám phá công nghệ mới?</h2>
        <p className="text-neutral-400 mb-8">Hàng ngàn sản phẩm đang chờ bạn.</p>
        
        <Link to="/products">
          <motion.button 
            whileHover={{ scale: 1.05, boxShadow: "0px 0px 20px rgba(79, 70, 229, 0.4)" }}
            whileTap={{ scale: 0.95 }}
            className="bg-indigo-600 text-white px-10 py-4 rounded-xl font-semibold transition"
          >
            Xem sản phẩm
          </motion.button>
        </Link>
      </motion.section>

    </div>
  );
}
