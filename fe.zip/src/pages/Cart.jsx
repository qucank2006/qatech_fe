import React from 'react';

const Cart = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Giỏ hàng</h1>
      <p>Các mặt hàng trong giỏ sẽ hiển thị ở đây.</p>
    </div>
  );
};

export default Cart;
